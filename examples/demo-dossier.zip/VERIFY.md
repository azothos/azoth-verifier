# Verifying this dossier independently

This dossier is **technical evidence supporting obligations** — it is not a
certification, guarantee, or attestation of compliance. Regulatory mapping
version: `2026-07`.

It is verifiable **without Azoth**. Independent checks:

## 1. Container integrity (`manifest.json`)

`manifest.json` lists every evidence file with its `sha256` and a `root_hash`.

Algorithm (reimplementable from this text alone):

1. For each file in `manifest.files` compute `sha256(file_bytes)` as
   lowercase hex, and confirm it equals the recorded `sha256`.
   (`manifest.json` itself is the index — it is not in its own file list.)
2. Take those hex strings, **sort them ascending** (lexicographic), and
   **concatenate them with no separator** into one string.
3. `root_hash = sha256(utf8(concatenation))`, lowercase hex. It must equal
   `manifest.root_hash`.

## 2. Sealed decision chain (`evidence.json`)

`evidence.json` is the sealed export: each entry carries `prevHash`,
`entryHash`, and a non-personal `core` object (no prompt/response content —
only hashes + metadata). Verify the hash chain:

1. **Canonical form** of an entry: `core_canonical = JSON.stringify(sortKeys(core))`
   where `sortKeys` sorts every object's keys ascending **recursively**, keeps
   array order, and **drops keys whose value is `undefined`**. Primitives pass
   through unchanged.
2. **Entry hash**: `entryHash == sha256( prevHash + core_canonical )`, lowercase
   hex over UTF-8 bytes. The concatenation is plain string concatenation (no
   separator byte). The genesis entry's `prevHash` is the empty string `""`.
3. **Linkage**: for entries ordered by `seq` ascending, seqs follow each other and
   each `prevHash` equals the previous entry's `entryHash`. A gap, insertion,
   reorder, or edit breaks this. A dossier for a later period starts from its
   first entry's `prevHash` (only `seq` 1 has an empty one).
4. **Filtered dossiers**: when the listed entries were filtered, `evidence.json`
   also holds `chain` — the whole segment as `{ seq, prevHash, entryHash,
   coreCanonical }`. Check the linkage on `chain`, then that each listed entry
   recomputes to its `entryHash` and equals the `chain` link of its `seq`.

The files and the chain are intact iff every file hash matches, `root_hash` matches,
and the chain verifies end to end. That alone does not show the dossier is complete:
entries cut from its start or its end, with the manifest recomputed, still form a
valid chain. The signature (section 4) binds it.

## 3. Trusted timestamp (`anchor.tsr`, when present)

When this dossier carries `anchor.tsr`, an RFC 3161 time-stamping authority
signed `manifest.root_hash` with its own clock: the token proves that every
file and every sealed decision above existed at its `genTime`, without
trusting Azoth. It is outside the manifest (it signs the manifest's
`root_hash`). Check that it covers exactly `root_hash` and chains to the
authority's **own published root** — not only to `tsa-chain.pem`, which ships
with the dossier:

```
openssl ts -verify -digest <manifest.root_hash> -in anchor.tsr -CAfile tsa-root.pem -untrusted tsa-chain.pem
azoth-verify dossier.zip --keys keys.jwks.json --tsa-root tsa-root.pem
```

## 4. Signature (`signature.jws`, required)

`signature.jws` is a compact JWS (EdDSA, Ed25519) by the workspace's key over
`manifest.root_hash` — outside the manifest, like `anchor.tsr`. Its claims also
commit what the dossier covers: its kind, the journal's head when it was exported
(`head`: seq and entry hash), the count and seq range of the listed entries
(`entries`) and the export's filters. A dossier without it, or signed by a key you
did not obtain yourself, does not verify: fetch the workspace's public keys from
Azoth (`/api/proof/keys/<workspace>`), not from this dossier, and give them with
`--keys`. The verifier then checks that `evidence.json` holds exactly what the
signature committed, and says how many later entries the dossier does not hold.

## Automated verification

Use the standalone CLI (zero runtime dependencies, no network):

```
azoth-verify dossier.zip --keys keys.jwks.json          # human-readable PASS/FAIL per check
azoth-verify dossier.zip --keys keys.jwks.json --json   # machine-readable, for CI
```

Exit code `0` = all checks PASS, `1` = any FAIL. The CLI reimplements the
algorithms above; it does not import Azoth application code, by design.
